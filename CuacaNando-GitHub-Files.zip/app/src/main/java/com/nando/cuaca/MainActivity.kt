package com.nando.cuaca
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*
class MainActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(32,48,32,32)
  val t=TextView(this);t.text="🌤️ Cuaca Nando";t.textSize=30f
  val c=TextView(this);c.text="Jakarta";c.textSize=20f
  val temp=TextView(this);temp.text="28°C";temp.textSize=52f
  val info=TextView(this);info.text="Kelembapan: 75%\nAngin: 12 km/j\nPeluang hujan: 30%";info.textSize=18f
  val btn=Button(this);btn.text="Perbarui Cuaca";btn.setOnClickListener{Toast.makeText(this,"Cuaca diperbarui",Toast.LENGTH_SHORT).show()}
  l.addView(t);l.addView(c);l.addView(temp);l.addView(info);l.addView(btn);setContentView(l)
 }
}