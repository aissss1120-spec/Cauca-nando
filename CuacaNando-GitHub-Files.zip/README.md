# Cuaca Nando
Native Android weather app. GitHub Actions builds `app-debug.apk`.

Important: generate the Gradle wrapper (`gradle wrapper`) before running the workflow if `gradlew` is not present.
